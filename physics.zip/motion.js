
function Data(location, accel, vel){
    this.location = location;
    this.vel = vel;
};


const dt = 0.025;

let A = new THREE.Vector3(1,2,3);

//define r(X,Y,Z)

let r = new Data(THREE.Vector3(50,30,20),THREE.Vector3());

sphere.position.set(r);

//draw scene
var render = function(){
    renderer.render(scene,camera);
};
var Resis = function(){
    return -THREE.Vector3(guiControls_X.b*X.vel + guiControls_X.k*X.location,guiControls_Y.b*Y.vel + guiControls_Y.k*Y.location,guiControls_Z.b*Z.vel + guiControls_Z.k*Z.location);
}

var Force = function(){
    return THREE.Vector3();//Resis();
}
var Accel = function(){
    return Force()/guiMass.m;
}

//game loop
var GameLoop = function(){

    requestAnimationFrame(GameLoop);

    r.vel += r.accel*dt;
    sphere.position += r.vel*dt;
    r.location += r.vel*dt;

    render();
}

GameLoop();